#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
#import sys
import socket
import ipaddress
import shutil
import platform
import random
import json
#import importlib.util
import configparser as ini
from util_core import downloader as dl
from util_core import (HOME_DIR, URL, URL2, common_install, common_remove)


def envSetup():
    #https://stackoverflow.com/a/1681244
    os.environ['PATH'] += os.pathsep + os.pathsep.join(
        [HOME_DIR + '/usr/bin', HOME_DIR + '/usr/sbin',
         os.getcwd()])


def isRoot():
    if os.getuid() != 0:
        exit('You must run this script as root!')


def isApt():
    if shutil.which('apt') is None:
        exit(
            'The script does not support the package manager in this operating system.'
        )


def isSystemctl():
    if shutil.which('systemctl'):
        if os.path.exists('/etc/systemd/system/ssmain.service') is False:
            dl.download(URL + '/init.d/ssmain.service', '/etc/systemd/system')
            if os.path.exists('/etc/systemd/system/ssmain.service') is False:
                exit('Download ' + '/etc/systemd/system/ssmain.service' +
                     ' failed')
            else:
                os.chmod('/etc/systemd/system/ssmain.service', 0o644)
            for i in [
                    'enable ssmain.service', 'daemon-reload', 'reset-failed'
            ]:
                subprocess.Popen('systemctl ' + i, shell=True).wait()
    else:
        exit('No command systemctl found.')


def isPython3():
    ver = platform.python_version_tuple()
    if int(ver[0]) < 3 or int(ver[0]) == 3 and int(ver[1]) < 7:
        exit('Python version < 3.7')
    if shutil.which('pip3') is None:
        #subprocess.run([common_install, "python3-pip"])
        subprocess.Popen(common_install + " python3-pip", shell=True).wait()


def dirCheck():
    if os.path.isdir(HOME_DIR) is False:
        os.mkdir(HOME_DIR, 0o755)
    for i in [
            'conf', 'usr', 'ssl', 'web', 'usr/bin', 'usr/conf', 'usr/etc',
            'usr/html', 'usr/lib', 'usr/php', 'usr/sbin', 'usr/fastcgi_temp',
            'usr/client_body_temp'
    ]:
        if os.path.isdir(HOME_DIR + '/' + i) is False:
            os.mkdir(HOME_DIR + '/' + i, 0o755)
        if os.path.exists(HOME_DIR + '/' + i) is False:
            exit('Create directory ' + HOME_DIR + '/' + i + ' failed')


def aclCheck():
    if os.path.isfile(HOME_DIR + '/conf/server_block.acl') is False:
        dl.download(URL + '/acl/server_block.acl', HOME_DIR + '/conf')
    if os.path.exists(HOME_DIR + '/conf/server_block.acl') is False:
        exit('Download ' + HOME_DIR + '/conf/server_block.acl' + ' failed')


def confCheck():
    if os.path.isfile(HOME_DIR + '/conf/config.ini') is False:
        dl.download(URL + '/conf/config.ini', HOME_DIR + '/conf')
    if os.path.exists(HOME_DIR + '/conf/config.ini') is False:
        exit('Download ' + HOME_DIR + '/conf/config.ini' + ' failed')


def dlBinary():
    if os.path.isfile(HOME_DIR + '/conf/update') is False:
        dl.download(URL + '/version/update', HOME_DIR + '/conf')
    with open(HOME_DIR + '/conf/update', 'r') as fd:
        url = URL + '/usr/bin/kcptun.sh'
        for line in fd.read().splitlines():
            sha, file = line.split()
            dir, name = os.path.split(file)
            if name == 'ss-main' or name == 'ss-tool':
                continue
            url += URL + '/usr/bin/' + name + ' '
        if os.path.exists(file) is False:
            dl.download(url, dir)
    with open(HOME_DIR + '/conf/update', 'r') as fd:
        for line in fd.read().splitlines():
            sha, file = line.split()
            dir, name = os.path.split(file)
            if name == 'ss-main' or name == 'ss-tool':
                continue
            if os.path.exists(file) is False:
                exit('Download ' + file + ' failed')
            else:
                os.chmod(file, 0o755)
            if file == '/etc/ssmanager/usr/bin/ssmain' and not os.path.islink(
                    '/usr/local/bin/ssmain'):
                os.remove('/usr/local/bin/ssmain')
                os.symlink('/etc/ssmanager/usr/bin/ssmain',
                           '/usr/local/bin/ssmain')


def port_is_use(ipv: int, port: int) -> bool:
    #https://www.kite.com/python/answers/how-to-check-if-a-network-port-is-open-in-python
    if ipv == 4:
        t_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        u_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        addr = '0.0.0.0'
    elif ipv == 6:
        t_socket = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        u_socket = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        addr = '::'
    else:
        exit(ipv)
    tcp_use, udp_use = False, False
    try:
        t_socket.bind((addr, int(port)))
    except OSError as err:
        tcp_use = True
    finally:
        t_socket.close()
    try:
        u_socket.bind((addr, int(port)))
    except OSError as err:
        udp_use = True
    finally:
        u_socket.close()
    return tcp_use or udp_use


def random_num(start_port: int, end_port: int) -> int:
    return random.randint(start_port, end_port)


def random_port(start_port: int = 1024, end_port: int = 65535):
    while True:
        random_port = random_num(start_port, end_port)
        if not port_is_use(4, random_port) and not port_is_use(6, random_port):
            return random_port


def random_str(max: int):
    return (''.join(
        random.sample([
            'z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n',
            'm', 'l', 'k', 'j', 'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a',
            '9', '8', '7', '6', '5', '4', '3', '2', '1', '0'
        ], max)))


def controller_ipc(string: str) -> str:
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    sock.bind('/tmp/ssclient.socket')
    sock.connect('/tmp/ss-manager.socket')
    sock.sendall(string.encode())
    data = sock.recv(1506).decode()
    sock.close()
    os.remove('/tmp/ssclient.socket')
    return data


def extract_ip(ipv: int = 4):
    #https://www.delftstack.com/howto/python/get-ip-address-python/
    if ipv == 4:
        try:
            st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            st.connect(('8.8.8.8', 1))
        except OSError as err:
            print("IPv4: {0}".format(err.strerror))
            exit(1)
    if ipv == 6:
        try:
            st = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
            st.connect(('2001:4860:4860::8888', 1))
        except OSError as err:
            print("IPv6: {0}".format(err.strerror))
            exit(1)
    IP = st.getsockname()[0]
    st.close()
    return IP


def is_ipv4(ip):
    try:
        socket.inet_pton(socket.AF_INET, ip)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(ip)
        except socket.error:
            return False
        return ip.count('.') == 3
    except socket.error:  # not a valid ip
        return False
    return True


def is_ipv6(ip):
    try:
        socket.inet_pton(socket.AF_INET6, ip)
    except socket.error:  # not a valid ip
        return False
    return True


def check_ip(ip) -> bool:
    return is_ipv4(ip) or is_ipv6(ip)


def ipv4_or_ipv6(ip) -> int:
    if check_ip(ip):
        if is_ipv4(ip):
            return 4
        if is_ipv6(ip):
            return 6
    return False


def env_get(str):
    return os.getenv(str)


def pid() -> int:
    return os.getpid()


def is_global(ip) -> bool:
    #https://www.geeksforgeeks.org/how-to-manipulate-ip-addresses-in-python-using-ipaddress-module/
    return ipaddress.ip_address(ip).is_global


'''
#此特性3.8后才支持
def mod_check(name: str) -> int:
    #https://stackoverflow.com/questions/1051254/check-if-python-package-is-installed

    if name in sys.modules:
        #print(f"{name!r} already in sys.modules")
        return 0
    elif (spec := importlib.util.find_spec(name)) is not None:
        # If you choose to perform the actual import ...
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        #print(f"{name!r} has been imported")
        return 1
    else:
        #print(f"can't find the {name!r} module")
        return 2
'''


def module_check() -> list:
    list = []
    try:
        import daemon
    except ImportError as e:
        list.append('python-daemon')
    try:
        import rich
    except ImportError as e:
        list.append('rich')
    return list


def pause():
    input('Press any key to start...or Press Ctrl+D to cancel')


def address_lookup() -> str:
    try:
        with urllib.request.urlopen('https://ipapi.co/json', timeout=3) as f:
            data = json.loads(f.read().decode('utf-8'))
            city = data['city']
            region = data['region']
            country_name = data['country_name']
            return city + ', ' + region + ', ' + country_name
    except urllib.error.URLError as e:
        print(e.reason)
        exit(1)
    try:
        req = urllib.request.Request('https://myip.ipip.net')
        urllib.request.urlopen(req, timeout=3)
        with urllib.request.urlopen(req) as response:
            data = response.read().decode('utf-8')
            data = data.split('：')[2]
    except urllib.error.URLError as e:
        try:
            req = urllib.request.Request(
                "https://ip.taobao.com/outGetIpInfo?ip=${ipv4:-$ipv6}&accessKey=alibaba-inc"
            )
            urllib.request.urlopen(req)
            with urllib.request.urlopen(req) as response:
                data = response.read().decode('utf-8')
        except urllib.error.URLError as e:
            print(e.reason)
            exit(1)
        else:
            data = json.loads(data)
            if data['code'] == 0:
                data = data['data']['country'] + ', ' + data['data'][
                    'region'] + ', ' + data['data']['country_id'].replace(
                        'CN', 'TW')
            elif data['code'] == 1:
                print('服务器异常')
            elif data['code'] == 2:
                print('请求参数异常')
            elif data['code'] == 3:
                print('服务器繁忙')
            elif data['code'] == 4:
                print('个人qps超出')
        if len(data) != 0:
            if '台湾' in data:
                data = data.replace('中国', '中华民国')
            return data.strip()


def parsing_user(data: str) -> list:
    dict = {}
    for line in data.split('|'):
        key, val = line.split('^')
        if 'server_port' == key:
            dict['server_port'] = val
        if 'password' == key:
            dict['password'] = val
        if 'method' == key:
            dict['method'] = val
        if 'plugin' == key:
            dict['plugin'] = val
        if 'plugin_opts' == key:
            dict['plugin_opts'] = val
        if 'total' == key:
            dict['total'] = val
    return dict


def parsing_plugin_opts(data: str, key: str):
    for line in data.split(';'):
        if line == key:
            return True
        if key == line.split('=')[0]:
            return line.split('=')[1]


def traffic(data: int = 0):
    if data < 1024:
        return str(data) + ' Bytes'
    elif data < 1024**2:
        return ('%.2f' % (data / 1024) + ' KB')
    elif data < 1024**3:
        return ('%.2f' % (data / 1024**2) + ' MB')
    elif data < 1024**4:
        return ('%.2f' % (data / 1024**3) + ' GB')
    elif data < 1024**5:
        return ('%.2f' % (data / 1024**4) + ' TB')
    elif data < 1024**6:
        return ('%.2f' % (data / 1024**5) + ' PB')
    elif data < 1024**7:
        return ('%.2f' % (data / 1024**6) + ' EB')
    elif data < 1024**8:
        return ('%.2f' % (data / 1024**7) + ' ZB')
    elif data < 1024**9:
        return ('%.2f' % (data / 1024**8) + ' YB')


def used_traffic(port: int = 0):
    data = json.loads(controller_ipc('ping')[6:-1])
    return data[str(port)]


def runing(file: str) -> bool:
    if os.path.isfile(file):
        with open(file, 'r') as fd:
            if os.path.isdir('/proc/' + fd.read()):
                return True
    return False
